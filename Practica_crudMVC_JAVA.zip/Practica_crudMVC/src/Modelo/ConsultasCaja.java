package Modelo;

import java.sql.*;

public class ConsultasCaja extends Conexion {

    public boolean registrar(Caja caj) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO cajas (numreferencia, contenido, precio, almacen) VALUES (?,?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, caj.getNumReferencia());
            ps.setString(2, caj.getContenido());
            ps.setInt(3, caj.getPrecio());
            ps.setInt(4, caj.getAlmacen());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean modificar(Caja caj) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE cajas SET contenido=?, precio=?, almacen=? WHERE numreferencia=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, caj.getContenido());
            ps.setInt(2, caj.getPrecio());
            ps.setInt(3, caj.getAlmacen());
            ps.setInt(4, caj.getNumReferencia());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminar(Caja caj) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM cajas WHERE numreferencia=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, caj.getNumReferencia());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean buscar(Caja caj) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM cajas WHERE numreferencia=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, caj.getNumReferencia());
            rs = ps.executeQuery();

            if (rs.next()) {
                caj.setNumReferencia(Integer.parseInt(rs.getString("numreferencia")));
                caj.setContenido(rs.getString("contenido"));
                caj.setPrecio(Integer.parseInt(rs.getString("precio")));
                caj.setAlmacen(Integer.parseInt(rs.getString("almacen")));
                return true;
            }

            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
}