package Modelo;

public class Caja {

    private int numReferencia;
    private String contenido;
    private int precio;
    private int almacen;

    public Caja() {
        this.numReferencia = 0;
        this.contenido = "";
        this.precio = 0;
        this.almacen = 0;
    }

    public Caja(int numReferencia, String contenido, int precio, int almacen) {
        this.numReferencia = numReferencia;
        this.contenido = contenido;
        this.precio = precio;
        this.almacen = almacen;
    }

    public int getNumReferencia() {
        return numReferencia;
    }

    public void setNumReferencia(int numReferencia) {
        this.numReferencia = numReferencia;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getAlmacen() {
        return almacen;
    }

    public void setAlmacen(int almacen) {
        this.almacen = almacen;
    }
}