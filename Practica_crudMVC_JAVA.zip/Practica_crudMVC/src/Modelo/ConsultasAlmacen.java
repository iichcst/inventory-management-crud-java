package Modelo;

import java.sql.*;

public class ConsultasAlmacen extends Conexion {

    public boolean registrar(Almacen alm) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO almacenes (codigo, lugar, capacidad) VALUES (?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, alm.getCodigo());
            ps.setString(2, alm.getLugar());
            ps.setInt(3, alm.getCapacidad());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean modificar(Almacen alm) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE almacenes SET lugar=?, capacidad=? WHERE codigo=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, alm.getLugar());
            ps.setInt(2, alm.getCapacidad());
            ps.setInt(3, alm.getCodigo());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean eliminar(Almacen alm) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE FROM almacenes WHERE codigo=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, alm.getCodigo());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }

    public boolean buscar(Almacen alm) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM almacenes WHERE codigo=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, alm.getCodigo());
            rs = ps.executeQuery();

            if (rs.next()) {
                alm.setCodigo(Integer.parseInt(rs.getString("codigo")));
                alm.setLugar(rs.getString("lugar"));
                alm.setCapacidad(Integer.parseInt(rs.getString("capacidad")));
                return true;
            }

            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
}