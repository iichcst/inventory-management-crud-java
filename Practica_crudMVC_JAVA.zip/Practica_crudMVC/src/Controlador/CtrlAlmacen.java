package Controlador;

import Modelo.Almacen;
import Modelo.ConsultasAlmacen;
import Vista.frmAlmacen;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class CtrlAlmacen implements ActionListener {

    private final Almacen modelo;
    private final ConsultasAlmacen consultas;
    private final frmAlmacen vista;

    public CtrlAlmacen(Almacen modelo, ConsultasAlmacen consultas, frmAlmacen vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.btnBuscar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    public void iniciar() {
        vista.setTitle("Control Almacenes");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    public void limpiar() {
        vista.txtCodigo.setText("");
        vista.txtLugar.setText("");
        vista.txtCapacidad.setText("");
        vista.txtCodigo.requestFocus();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // Botón Guardar
        if (e.getSource() == vista.btnGuardar) {
            modelo.setCodigo(Integer.parseInt(vista.txtCodigo.getText()));
            modelo.setLugar(vista.txtLugar.getText());
            modelo.setCapacidad(Integer.parseInt(vista.txtCapacidad.getText()));

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro guardado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar");
                limpiar();
            }
        }

        // Botón Modificar
        if (e.getSource() == vista.btnModificar) {
            modelo.setCodigo(Integer.parseInt(vista.txtCodigo.getText()));
            modelo.setLugar(vista.txtLugar.getText());
            modelo.setCapacidad(Integer.parseInt(vista.txtCapacidad.getText()));

            if (consultas.modificar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro modificado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar");
                limpiar();
            }
        }

        // Botón Eliminar
        if (e.getSource() == vista.btnEliminar) {
            modelo.setCodigo(Integer.parseInt(vista.txtCodigo.getText()));

            if (consultas.eliminar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro eliminado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar");
                limpiar();
            }
        }

        // Botón Buscar
        if (e.getSource() == vista.btnBuscar) {
            modelo.setCodigo(Integer.parseInt(vista.txtCodigo.getText()));

            if (consultas.buscar(modelo)) {
                vista.txtCodigo.setText(String.valueOf(modelo.getCodigo()));
                vista.txtLugar.setText(modelo.getLugar());
                vista.txtCapacidad.setText(String.valueOf(modelo.getCapacidad()));
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el registro");
                limpiar();
            }
        }

        // Botón Limpiar
        if (e.getSource() == vista.btnLimpiar) {
            limpiar();
        }
    }
}