package Controlador;

import Modelo.ConsultasCaja;
import Modelo.Caja;
import Vista.frmCaja;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class CtrlCaja implements ActionListener {

    private final Caja modelo;
    private final ConsultasCaja consultas;
    private final frmCaja vista;

    public CtrlCaja(Caja modelo, ConsultasCaja consultas, frmCaja vista) {
        this.modelo = modelo;
        this.consultas = consultas;
        this.vista = vista;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.btnBuscar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    public void iniciar() {
        vista.setTitle("Control Cajas");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    public void limpiar() {
        vista.txtNumReferencia.setText("");
        vista.txtContenido.setText("");
        vista.txtPrecio.setText("");
        vista.txtAlmacen.setText("");
        vista.txtNumReferencia.requestFocus();
    }

    public void actionPerformed(ActionEvent e) {

        // botonGuardar
        if (e.getSource() == vista.btnGuardar) {
            modelo.setNumReferencia(
                    Integer.parseInt(vista.txtNumReferencia.getText())
            );
            modelo.setContenido(vista.txtContenido.getText());
            modelo.setPrecio(
                    Integer.parseInt(vista.txtPrecio.getText())
            );
            modelo.setAlmacen(
                    Integer.parseInt(vista.txtAlmacen.getText())
            );

            if (consultas.registrar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro guardado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar");
                limpiar();
            }
        }

        // botonModificar
        if (e.getSource() == vista.btnModificar) {
            modelo.setNumReferencia(
                    Integer.parseInt(vista.txtNumReferencia.getText())
            );
            modelo.setContenido(vista.txtContenido.getText());
            modelo.setPrecio(
                    Integer.parseInt(vista.txtPrecio.getText())
            );
            modelo.setAlmacen(
                    Integer.parseInt(vista.txtAlmacen.getText())
            );

            if (consultas.modificar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro modificado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar");
                limpiar();
            }
        }

        // botonEliminar
        if (e.getSource() == vista.btnEliminar) {
            modelo.setNumReferencia(
                    Integer.parseInt(vista.txtNumReferencia.getText())
            );

            if (consultas.eliminar(modelo)) {
                JOptionPane.showMessageDialog(null, "Registro eliminado");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar");
                limpiar();
            }
        }

        // botonBuscar
        if (e.getSource() == vista.btnBuscar) {
            modelo.setNumReferencia(
                    Integer.parseInt(vista.txtNumReferencia.getText())
            );

            if (consultas.buscar(modelo)) {
                vista.txtNumReferencia.setText(
                        String.valueOf(modelo.getNumReferencia())
                );
                vista.txtContenido.setText(modelo.getContenido());
                vista.txtPrecio.setText(
                        String.valueOf(modelo.getPrecio())
                );
                vista.txtAlmacen.setText(
                        String.valueOf(modelo.getAlmacen())
                );
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el registro");
                limpiar();
            }
        }

        // botonLimpiar
        if (e.getSource() == vista.btnLimpiar) {
            limpiar();
        }
    }
}