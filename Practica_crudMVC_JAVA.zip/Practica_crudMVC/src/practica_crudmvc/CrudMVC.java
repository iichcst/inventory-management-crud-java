
package practica_crudmvc;

import Controlador.CtrlCaja;
import Modelo.ConsultasCaja;
import Modelo.Caja;
import Vista.frmCaja;

import Controlador.CtrlAlmacen;
import Modelo.ConsultasAlmacen;
import Modelo.Almacen;
import Vista.frmAlmacen;

public class CrudMVC {

    public static void main(String[] args) {

        Caja modCaja = new Caja();
        ConsultasCaja modCCaja = new ConsultasCaja();
        frmCaja vistaCaja = new frmCaja();

        CtrlCaja ctrlCaja = new CtrlCaja(modCaja, modCCaja, vistaCaja);
        ctrlCaja.iniciar();

        Almacen modAlmacen = new Almacen();
        ConsultasAlmacen modCAlmacen = new ConsultasAlmacen();
        frmAlmacen vistaAlmacen = new frmAlmacen();

        CtrlAlmacen ctrlAlmacen = new CtrlAlmacen(
                modAlmacen,
                modCAlmacen,
                vistaAlmacen
        );

        ctrlAlmacen.iniciar();
    }
}